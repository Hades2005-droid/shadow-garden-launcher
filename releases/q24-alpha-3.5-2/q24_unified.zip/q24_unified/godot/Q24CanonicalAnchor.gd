## Q24CanonicalAnchor.gd
## Symbolic-only anchor resource for the Shadow Garden Q24 alpha.
## Carries the canonical identifier, the 19->10->1 ignition sequence,
## Temperance-14 anchor (unreduced), and Fable5 bedrock cross-refs.
## This resource is metadata only. It is NOT physics, NOT executable
## authority, and NOT a safety override. Consumers must treat it as
## symbolic labeling for the state machine and scene registry.
class_name Q24CanonicalAnchor
extends Resource

@export var canonical_id: String = "q24_eternal_dao_temperance_14_harmony_paradox_ignite_19_10_1"
@export var symbolic_only: bool = true
@export var sequence: PackedInt32Array = PackedInt32Array([19, 10, 1])
@export var anchor: int = 14
@export var reduce_anchor: bool = false
@export var carrier: String = "love_and_harmony_6"

@export_group("Display Names")
@export var display_en: String = "Eternal Dao: Temperance 14, Perfect Harmony Paradox"
@export var display_zh: String = ""
@export var display_ja: String = ""
@export var display_ko: String = ""

@export_group("Ignition")
@export var ignition_path: String = "19 -> 10 -> 1"

@export_group("Fable5 Bedrock Bindings")
@export var fable5_bedrock_version: String = "0.4.0-engine-bedrock-10"
@export var quantum_gap_sig: String = ""
@export var catalyst_circle_sig: String = ""
@export var bridge_signature: String = ""
@export var primordial_five: PackedStringArray = PackedStringArray()
@export var sovereign_zero: String = "hades"

func to_dict() -> Dictionary:
	return {
		"id": canonical_id,
		"symbolic_only": symbolic_only,
		"sequence": Array(sequence),
		"anchor": anchor,
		"reduce_anchor": reduce_anchor,
		"carrier": carrier,
		"ignition_path": ignition_path,
		"display": {
			"en": display_en,
			"zh": display_zh,
			"ja": display_ja,
			"ko": display_ko,
		},
		"bindings": {
			"fable5_bedrock_version": fable5_bedrock_version,
			"quantum_gap_sig": quantum_gap_sig,
			"catalyst_circle_sig": catalyst_circle_sig,
			"bridge_signature": bridge_signature,
			"primordial_five": Array(primordial_five),
			"sovereign_zero": sovereign_zero,
		},
	}
